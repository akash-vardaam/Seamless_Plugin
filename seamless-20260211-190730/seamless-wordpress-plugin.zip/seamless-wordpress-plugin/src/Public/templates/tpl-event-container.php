<?php get_header(); ?>

<div class="seamless-event-container">
  <?php echo do_shortcode('[seamless_event_list]'); ?>
</div>

<?php get_footer(); ?>
